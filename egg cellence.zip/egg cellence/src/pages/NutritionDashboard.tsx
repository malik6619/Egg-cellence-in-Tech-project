import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Egg, 
  Zap, 
  Heart, 
  Shield, 
  Brain,
  Eye,
  Bone,
  Droplets
} from 'lucide-react';

export default function NutritionDashboard() {
  const nutritionData = {
    calories: 70,
    protein: 6,
    fat: 5,
    carbs: 0.6,
    cholesterol: 186,
    sodium: 70
  };

  const vitamins = [
    { name: 'Vitamin A', amount: '6%', icon: <Eye className="h-4 w-4" />, color: 'bg-orange-500' },
    { name: 'Vitamin D', amount: '41%', icon: <Bone className="h-4 w-4" />, color: 'bg-yellow-500' },
    { name: 'Vitamin B12', amount: '9%', icon: <Brain className="h-4 w-4" />, color: 'bg-red-500' },
    { name: 'Folate', amount: '5%', icon: <Heart className="h-4 w-4" />, color: 'bg-green-500' },
    { name: 'Riboflavin', amount: '15%', icon: <Zap className="h-4 w-4" />, color: 'bg-blue-500' },
    { name: 'Selenium', amount: '22%', icon: <Shield className="h-4 w-4" />, color: 'bg-purple-500' }
  ];

  const minerals = [
    { name: 'Iron', amount: '5%', daily: '0.9mg' },
    { name: 'Phosphorus', amount: '10%', daily: '99mg' },
    { name: 'Zinc', amount: '5%', daily: '0.6mg' },
    { name: 'Calcium', amount: '3%', daily: '28mg' }
  ];

  const benefits = [
    {
      title: "High-Quality Protein",
      description: "Contains all 9 essential amino acids for muscle building and repair",
      icon: <Zap className="h-6 w-6 text-orange-500" />
    },
    {
      title: "Brain Health",
      description: "Rich in choline, essential for brain development and function",
      icon: <Brain className="h-6 w-6 text-orange-500" />
    },
    {
      title: "Eye Protection",
      description: "Lutein and zeaxanthin help protect against age-related eye conditions",
      icon: <Eye className="h-6 w-6 text-orange-500" />
    },
    {
      title: "Heart Healthy",
      description: "Contains healthy fats and nutrients that support cardiovascular health",
      icon: <Heart className="h-6 w-6 text-orange-500" />
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Egg className="h-16 w-16 text-orange-500" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Egg Nutrition Dashboard</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover the incredible nutritional power packed into every egg
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 bg-white shadow-lg">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="vitamins">Vitamins</TabsTrigger>
            <TabsTrigger value="minerals">Minerals</TabsTrigger>
            <TabsTrigger value="benefits">Benefits</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Macronutrients */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-white shadow-lg">
                <CardHeader className="text-center">
                  <CardTitle className="text-3xl font-bold text-orange-600">{nutritionData.calories}</CardTitle>
                  <CardDescription>Calories per large egg</CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-orange-500" />
                    Protein
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-gray-800 mb-2">{nutritionData.protein}g</div>
                  <Progress value={75} className="h-2" />
                  <p className="text-sm text-gray-600 mt-2">75% of daily protein quality</p>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Droplets className="h-5 w-5 text-orange-500" />
                    Healthy Fats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-gray-800 mb-2">{nutritionData.fat}g</div>
                  <Progress value={60} className="h-2" />
                  <p className="text-sm text-gray-600 mt-2">Includes omega-3 fatty acids</p>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Breakdown */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle>Nutritional Breakdown (per large egg)</CardTitle>
                <CardDescription>Complete nutritional profile</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <div className="text-lg font-semibold text-gray-800">Carbs</div>
                    <div className="text-2xl font-bold text-orange-600">{nutritionData.carbs}g</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-lg font-semibold text-gray-800">Cholesterol</div>
                    <div className="text-2xl font-bold text-orange-600">{nutritionData.cholesterol}mg</div>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <div className="text-lg font-semibold text-gray-800">Sodium</div>
                    <div className="text-2xl font-bold text-orange-600">{nutritionData.sodium}mg</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vitamins" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vitamins.map((vitamin, index) => (
                <Card key={index} className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      {vitamin.icon}
                      {vitamin.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl font-bold text-gray-800">{vitamin.amount}</span>
                      <Badge className="bg-orange-100 text-orange-700">Daily Value</Badge>
                    </div>
                    <div className={`h-2 rounded-full ${vitamin.color} opacity-20`}>
                      <div 
                        className={`h-full rounded-full ${vitamin.color}`}
                        style={{ width: vitamin.amount }}
                      ></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="minerals" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {minerals.map((mineral, index) => (
                <Card key={index} className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-lg">{mineral.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xl font-bold text-gray-800">{mineral.amount}</span>
                      <span className="text-sm text-gray-600">{mineral.daily}</span>
                    </div>
                    <Progress value={parseInt(mineral.amount)} className="h-2" />
                    <p className="text-sm text-gray-600 mt-2">of daily recommended value</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="benefits" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <Card key={index} className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      {benefit.icon}
                      {benefit.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{benefit.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}