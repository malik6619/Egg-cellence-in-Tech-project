import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Search, 
  Calendar, 
  Clock, 
  ArrowRight,
  TrendingUp,
  Zap,
  Heart,
  Brain,
  Smartphone,
  ChefHat
} from 'lucide-react';

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const blogPosts = [
    {
      id: 1,
      title: "The Future of Egg Production: How AI is Revolutionizing Farming",
      excerpt: "Discover how artificial intelligence and IoT sensors are transforming modern egg farms, improving animal welfare and production efficiency.",
      author: "Dr. Sarah Chen",
      authorAvatar: "SC",
      date: "2024-01-15",
      readTime: "8 min read",
      category: "technology",
      image: "🤖",
      tags: ["AI", "farming", "technology", "innovation"],
      featured: true
    },
    {
      id: 2,
      title: "Protein Powerhouse: Why Eggs Are the Ultimate Superfood",
      excerpt: "A comprehensive look at the nutritional benefits of eggs and why they should be a staple in every healthy diet.",
      author: "Maria Rodriguez",
      authorAvatar: "MR",
      date: "2024-01-12",
      readTime: "6 min read",
      category: "nutrition",
      image: "💪",
      tags: ["nutrition", "protein", "health", "superfood"],
      featured: false
    },
    {
      id: 3,
      title: "From Farm to Table: Blockchain Technology in Egg Supply Chains",
      excerpt: "How blockchain is ensuring transparency and traceability in egg production, giving consumers confidence in their food choices.",
      author: "Tech Team",
      authorAvatar: "TT",
      date: "2024-01-10",
      readTime: "10 min read",
      category: "technology",
      image: "🔗",
      tags: ["blockchain", "supply-chain", "transparency", "food-safety"],
      featured: true
    },
    {
      id: 4,
      title: "5 Gourmet Egg Recipes That Will Impress Your Guests",
      excerpt: "Elevate your cooking game with these sophisticated egg dishes perfect for special occasions and dinner parties.",
      author: "Chef Antoine",
      authorAvatar: "CA",
      date: "2024-01-08",
      readTime: "12 min read",
      category: "recipes",
      image: "👨‍🍳",
      tags: ["recipes", "gourmet", "cooking", "entertaining"],
      featured: false
    },
    {
      id: 5,
      title: "The Science of Egg Cooking: Temperature, Timing, and Technique",
      excerpt: "Understanding the science behind perfect egg preparation, from the ideal temperature for scrambling to the chemistry of poaching.",
      author: "Food Science Lab",
      authorAvatar: "FS",
      date: "2024-01-05",
      readTime: "9 min read",
      category: "science",
      image: "🔬",
      tags: ["science", "cooking", "temperature", "technique"],
      featured: false
    },
    {
      id: 6,
      title: "Smart Kitchen Apps: The Best Tools for Egg Enthusiasts",
      excerpt: "A roundup of the latest mobile apps and smart kitchen gadgets designed to help you cook perfect eggs every time.",
      author: "App Review Team",
      authorAvatar: "AR",
      date: "2024-01-03",
      readTime: "7 min read",
      category: "technology",
      image: "📱",
      tags: ["apps", "smart-kitchen", "gadgets", "cooking-tools"],
      featured: false
    },
    {
      id: 7,
      title: "Egg Myths Debunked: Separating Fact from Fiction",
      excerpt: "We tackle the most common misconceptions about eggs, from cholesterol concerns to storage myths, with evidence-based facts.",
      author: "Nutrition Facts Team",
      authorAvatar: "NF",
      date: "2024-01-01",
      readTime: "11 min read",
      category: "nutrition",
      image: "🧠",
      tags: ["myths", "facts", "nutrition", "health"],
      featured: true
    },
    {
      id: 8,
      title: "Sustainable Egg Production: The Rise of Regenerative Farming",
      excerpt: "How innovative farming practices are making egg production more sustainable while improving soil health and biodiversity.",
      author: "Green Farm Initiative",
      authorAvatar: "GF",
      date: "2023-12-28",
      readTime: "8 min read",
      category: "sustainability",
      image: "🌱",
      tags: ["sustainability", "regenerative", "farming", "environment"],
      featured: false
    }
  ];

  const categories = [
    { id: 'all', name: 'All Articles', icon: <Search className="h-4 w-4" /> },
    { id: 'nutrition', name: 'Nutrition', icon: <Heart className="h-4 w-4" /> },
    { id: 'technology', name: 'Technology', icon: <Smartphone className="h-4 w-4" /> },
    { id: 'recipes', name: 'Recipes', icon: <ChefHat className="h-4 w-4" /> },
    { id: 'science', name: 'Science', icon: <Brain className="h-4 w-4" /> },
    { id: 'sustainability', name: 'Sustainability', icon: <TrendingUp className="h-4 w-4" /> }
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = filteredPosts.filter(post => post.featured);
  const regularPosts = filteredPosts.filter(post => !post.featured);

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'nutrition': 'bg-green-100 text-green-700',
      'technology': 'bg-blue-100 text-blue-700',
      'recipes': 'bg-orange-100 text-orange-700',
      'science': 'bg-purple-100 text-purple-700',
      'sustainability': 'bg-emerald-100 text-emerald-700'
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Egg-cellence Blog</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Latest insights on egg nutrition, innovative recipes, and cutting-edge food technology
          </p>
        </div>

        {/* Search and Categories */}
        <div className="mb-12 space-y-6">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white shadow-lg"
            />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center gap-2 ${
                  selectedCategory === category.id 
                    ? "bg-orange-500 hover:bg-orange-600" 
                    : "border-orange-200 text-orange-600 hover:bg-orange-50"
                }`}
              >
                {category.icon}
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Featured Articles */}
        {featuredPosts.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center gap-2 mb-8">
              <Zap className="h-6 w-6 text-orange-500" />
              <h2 className="text-2xl font-bold text-gray-800">Featured Articles</h2>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.slice(0, 2).map((post) => (
                <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white overflow-hidden">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Badge className={getCategoryColor(post.category)}>
                        {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
                      </Badge>
                      <div className="text-4xl">{post.image}</div>
                    </div>
                    <CardTitle className="text-xl group-hover:text-orange-600 transition-colors">
                      {post.title}
                    </CardTitle>
                    <CardDescription className="text-gray-600 line-clamp-3">
                      {post.excerpt}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-orange-100 text-orange-700 text-xs">
                            {post.authorAvatar}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-sm font-medium">{post.author}</div>
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <Calendar className="h-3 w-3" />
                            <span>{new Date(post.date).toLocaleDateString()}</span>
                            <span>•</span>
                            <Clock className="h-3 w-3" />
                            <span>{post.readTime}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <Button className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white">
                      Read Article <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Regular Articles */}
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-8">Latest Articles</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {regularPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white">
                <CardHeader>
                  <div className="flex items-center justify-between mb-4">
                    <Badge className={getCategoryColor(post.category)}>
                      {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
                    </Badge>
                    <div className="text-3xl">{post.image}</div>
                  </div>
                  <CardTitle className="text-lg group-hover:text-orange-600 transition-colors line-clamp-2">
                    {post.title}
                  </CardTitle>
                  <CardDescription className="text-gray-600 line-clamp-3">
                    {post.excerpt}
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center gap-2 mb-4">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="bg-orange-100 text-orange-700 text-xs">
                        {post.authorAvatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-sm text-gray-600">{post.author}</div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <Calendar className="h-3 w-3" />
                    <span>{new Date(post.date).toLocaleDateString()}</span>
                    <span>•</span>
                    <Clock className="h-3 w-3" />
                    <span>{post.readTime}</span>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-4">
                    {post.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <Button variant="outline" className="w-full border-orange-200 text-orange-600 hover:bg-orange-50">
                    Read More <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-xl text-gray-600">No articles found matching your search.</p>
            <p className="text-gray-500">Try adjusting your search terms or browse different categories.</p>
          </div>
        )}

        {/* Newsletter Signup */}
        <section className="mt-20 py-16 px-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest articles on egg nutrition, recipes, and food technology innovations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input 
              placeholder="Enter your email" 
              className="bg-white border-0 flex-1"
            />
            <Button className="bg-white text-orange-600 hover:bg-gray-100">
              Subscribe
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}