import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, 
  Heart, 
  Share2, 
  Plus,
  Search,
  TrendingUp,
  Users,
  Clock,
  ChefHat,
  Lightbulb,
  HelpCircle
} from 'lucide-react';

export default function Community() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const forumPosts = [
    {
      id: 1,
      title: "Perfect Poached Eggs Every Time - My Secret Method!",
      author: "EggMaster2024",
      avatar: "EM",
      category: "cooking-tips",
      replies: 23,
      likes: 89,
      timeAgo: "2 hours ago",
      preview: "After years of trial and error, I've finally mastered the art of poaching eggs. Here's my foolproof method that works every single time...",
      tags: ["poached-eggs", "cooking-tips", "breakfast"]
    },
    {
      id: 2,
      title: "Egg Nutrition: Separating Facts from Myths",
      author: "NutritionNerd",
      avatar: "NN",
      category: "nutrition",
      replies: 45,
      likes: 156,
      timeAgo: "5 hours ago",
      preview: "Let's debunk some common myths about egg nutrition. Are eggs really bad for your cholesterol? The science might surprise you...",
      tags: ["nutrition", "health", "science"]
    },
    {
      id: 3,
      title: "My Chickens Started Laying Blue Eggs!",
      author: "BackyardFarmer",
      avatar: "BF",
      category: "farming",
      replies: 12,
      likes: 67,
      timeAgo: "1 day ago",
      preview: "I'm so excited! My Ameraucana chickens just started laying the most beautiful blue eggs. Has anyone else experienced this?",
      tags: ["chickens", "farming", "blue-eggs"]
    },
    {
      id: 4,
      title: "Egg-based Meal Prep Ideas for Busy Professionals",
      author: "MealPrepPro",
      avatar: "MP",
      category: "meal-prep",
      replies: 34,
      likes: 123,
      timeAgo: "2 days ago",
      preview: "Working 60+ hours a week but still want nutritious meals? Here are my top 10 egg-based meal prep ideas that will save you time and money...",
      tags: ["meal-prep", "busy-lifestyle", "recipes"]
    },
    {
      id: 5,
      title: "Help! My Scrambled Eggs Always Turn Out Rubbery",
      author: "CookingNewbie",
      avatar: "CN",
      category: "help",
      replies: 18,
      likes: 34,
      timeAgo: "3 days ago",
      preview: "I've tried following so many recipes but my scrambled eggs always end up tough and rubbery. What am I doing wrong?",
      tags: ["help", "scrambled-eggs", "beginner"]
    },
    {
      id: 6,
      title: "The Science Behind Egg Shell Colors",
      author: "ScienceEgg",
      avatar: "SE",
      category: "science",
      replies: 28,
      likes: 91,
      timeAgo: "1 week ago",
      preview: "Ever wondered why some eggs are brown and others are white? The answer lies in the genetics of the chicken breed...",
      tags: ["science", "egg-shells", "genetics"]
    }
  ];

  const categories = [
    { id: 'all', name: 'All Posts', icon: <MessageSquare className="h-4 w-4" />, count: forumPosts.length },
    { id: 'cooking-tips', name: 'Cooking Tips', icon: <ChefHat className="h-4 w-4" />, count: 12 },
    { id: 'nutrition', name: 'Nutrition', icon: <TrendingUp className="h-4 w-4" />, count: 8 },
    { id: 'farming', name: 'Farming', icon: <Users className="h-4 w-4" />, count: 15 },
    { id: 'help', name: 'Help & Support', icon: <HelpCircle className="h-4 w-4" />, count: 6 },
    { id: 'science', name: 'Science', icon: <Lightbulb className="h-4 w-4" />, count: 9 }
  ];

  const topContributors = [
    { name: "EggMaster2024", posts: 45, likes: 892, avatar: "EM" },
    { name: "NutritionNerd", posts: 32, likes: 756, avatar: "NN" },
    { name: "ChefEggbert", posts: 28, likes: 634, avatar: "CE" },
    { name: "FarmFresh", posts: 23, likes: 445, avatar: "FF" }
  ];

  const filteredPosts = forumPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.preview.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'cooking-tips': 'bg-orange-100 text-orange-700',
      'nutrition': 'bg-green-100 text-green-700',
      'farming': 'bg-blue-100 text-blue-700',
      'help': 'bg-red-100 text-red-700',
      'science': 'bg-purple-100 text-purple-700',
      'meal-prep': 'bg-yellow-100 text-yellow-700'
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Egg Community Forum</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Connect with fellow egg enthusiasts, share tips, and learn from the community
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* New Post Button */}
            <Button className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white">
              <Plus className="mr-2 h-4 w-4" />
              New Post
            </Button>

            {/* Categories */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-orange-100 text-orange-700'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {category.icon}
                      <span className="text-sm font-medium">{category.name}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {category.count}
                    </Badge>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg">Top Contributors</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {topContributors.map((contributor, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-orange-100 text-orange-700 text-xs">
                        {contributor.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{contributor.name}</div>
                      <div className="text-xs text-gray-500">
                        {contributor.posts} posts • {contributor.likes} likes
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search discussions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white shadow-lg"
              />
            </div>

            {/* Forum Posts */}
            <div className="space-y-4">
              {filteredPosts.map((post) => (
                <Card key={post.id} className="bg-white shadow-lg hover:shadow-xl transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3 flex-1">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-orange-100 text-orange-700">
                            {post.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-lg hover:text-orange-600 transition-colors">
                            {post.title}
                          </CardTitle>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <span>by {post.author}</span>
                            <span>•</span>
                            <Clock className="h-3 w-3" />
                            <span>{post.timeAgo}</span>
                          </div>
                        </div>
                      </div>
                      <Badge className={getCategoryColor(post.category)}>
                        {post.category.replace('-', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <CardDescription className="text-gray-600 mb-4">
                      {post.preview}
                    </CardDescription>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex gap-2">
                        {post.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" />
                          <span>{post.replies}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="h-4 w-4" />
                          <span>{post.likes}</span>
                        </div>
                        <Button variant="ghost" size="sm" className="text-gray-500 hover:text-orange-600">
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredPosts.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-xl text-gray-600">No discussions found matching your search.</p>
                <p className="text-gray-500">Try adjusting your search terms or browse different categories.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}