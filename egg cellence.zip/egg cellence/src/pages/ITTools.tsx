import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Smartphone, 
  Brain, 
  Shield, 
  Plus,
  Minus,
  Calendar,
  Target,
  Zap,
  CheckCircle,
  AlertCircle,
  MapPin
} from 'lucide-react';

interface Recipe {
  name: string;
  time: string;
  difficulty: string;
  ingredients: string[];
  instructions: string[];
}

export default function ITTools() {
  const [eggCount, setEggCount] = useState(2);
  const [dailyGoal, setDailyGoal] = useState(2);
  const [weeklyData] = useState([
    { day: 'Mon', eggs: 2, goal: 2 },
    { day: 'Tue', eggs: 1, goal: 2 },
    { day: 'Wed', eggs: 3, goal: 2 },
    { day: 'Thu', eggs: 2, goal: 2 },
    { day: 'Fri', eggs: 1, goal: 2 },
    { day: 'Sat', eggs: 2, goal: 2 },
    { day: 'Sun', eggs: 2, goal: 2 }
  ]);

  const [recipePreferences, setRecipePreferences] = useState({
    dietary: '',
    cookingTime: '',
    difficulty: '',
    ingredients: ''
  });

  const [generatedRecipe, setGeneratedRecipe] = useState<Recipe | null>(null);

  const [trackingData] = useState({
    batchId: 'EGG-2024-001',
    farm: 'Sunny Valley Farm',
    location: 'California, USA',
    date: '2024-01-15',
    quality: 'Grade AA',
    organic: true,
    freeRange: true,
    status: 'Delivered'
  });

  const generateRecipe = () => {
    const recipes: Recipe[] = [
      {
        name: "Mediterranean Herb Scramble",
        time: "8 minutes",
        difficulty: "Easy",
        ingredients: ["3 eggs", "Olive oil", "Fresh herbs", "Feta cheese", "Cherry tomatoes"],
        instructions: [
          "Heat olive oil in pan",
          "Add cherry tomatoes and cook 2 minutes",
          "Whisk eggs with herbs",
          "Add eggs to pan and scramble gently",
          "Top with crumbled feta cheese"
        ]
      },
      {
        name: "Spicy Shakshuka Bowl",
        time: "20 minutes", 
        difficulty: "Medium",
        ingredients: ["4 eggs", "Tomato sauce", "Bell peppers", "Onions", "Paprika", "Cumin"],
        instructions: [
          "Sauté onions and peppers",
          "Add tomato sauce and spices",
          "Create wells for eggs",
          "Crack eggs into wells",
          "Cover and cook until set"
        ]
      },
      {
        name: "Protein Power Omelet",
        time: "12 minutes",
        difficulty: "Medium", 
        ingredients: ["3 eggs", "Spinach", "Mushrooms", "Cheese", "Avocado"],
        instructions: [
          "Sauté mushrooms and spinach",
          "Beat eggs and pour into pan",
          "Add filling to one half",
          "Fold omelet carefully",
          "Serve with sliced avocado"
        ]
      }
    ];

    const randomRecipe = recipes[Math.floor(Math.random() * recipes.length)];
    setGeneratedRecipe(randomRecipe);
  };

  const totalWeeklyEggs = weeklyData.reduce((sum, day) => sum + day.eggs, 0);
  const weeklyGoal = weeklyData.reduce((sum, day) => sum + day.goal, 0);
  const weeklyProgress = (totalWeeklyEggs / weeklyGoal) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Egg-cellent IT Tools</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Innovative technology solutions to enhance your egg experience
          </p>
        </div>

        <Tabs defaultValue="tracker" className="space-y-8">
          <TabsList className="grid w-full grid-cols-3 bg-white shadow-lg">
            <TabsTrigger value="tracker" className="flex items-center gap-2">
              <Smartphone className="h-4 w-4" />
              Egg Tracker
            </TabsTrigger>
            <TabsTrigger value="generator" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Recipe Generator
            </TabsTrigger>
            <TabsTrigger value="supply" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Supply Chain
            </TabsTrigger>
          </TabsList>

          {/* Egg Tracker */}
          <TabsContent value="tracker" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Daily Tracker */}
              <Card className="bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-orange-500" />
                    Daily Egg Tracker
                  </CardTitle>
                  <CardDescription>Track your daily egg consumption and nutrition goals</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-6xl font-bold text-orange-500 mb-2">{eggCount}</div>
                    <p className="text-gray-600">Eggs consumed today</p>
                  </div>

                  <div className="flex justify-center gap-4">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setEggCount(Math.max(0, eggCount - 1))}
                      className="border-orange-200 text-orange-600 hover:bg-orange-50"
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setEggCount(eggCount + 1)}
                      className="border-orange-200 text-orange-600 hover:bg-orange-50"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label>Daily Goal</Label>
                    <Select value={dailyGoal.toString()} onValueChange={(value) => setDailyGoal(parseInt(value))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 egg per day</SelectItem>
                        <SelectItem value="2">2 eggs per day</SelectItem>
                        <SelectItem value="3">3 eggs per day</SelectItem>
                        <SelectItem value="4">4 eggs per day</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{Math.round((eggCount / dailyGoal) * 100)}%</span>
                    </div>
                    <Progress value={(eggCount / dailyGoal) * 100} className="h-2" />
                  </div>

                  {eggCount >= dailyGoal && (
                    <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-lg">
                      <CheckCircle className="h-5 w-5" />
                      <span className="font-medium">Daily goal achieved!</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Weekly Overview */}
              <Card className="bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-orange-500" />
                    Weekly Overview
                  </CardTitle>
                  <CardDescription>Your egg consumption this week</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-orange-500 mb-1">{totalWeeklyEggs}</div>
                    <p className="text-gray-600">Total eggs this week</p>
                  </div>

                  <div className="space-y-3">
                    {weeklyData.map((day, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{day.day}</span>
                        <div className="flex items-center gap-2">
                          <div className="flex gap-1">
                            {[...Array(day.goal)].map((_, i) => (
                              <div
                                key={i}
                                className={`w-3 h-3 rounded-full ${
                                  i < day.eggs ? 'bg-orange-400' : 'bg-gray-200'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">{day.eggs}/{day.goal}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Weekly Progress</span>
                      <span>{Math.round(weeklyProgress)}%</span>
                    </div>
                    <Progress value={weeklyProgress} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Nutrition Insights */}
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-orange-500" />
                  Nutrition Insights
                </CardTitle>
                <CardDescription>Based on your current consumption</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{eggCount * 6}g</div>
                    <div className="text-sm text-gray-600">Protein today</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{eggCount * 70}</div>
                    <div className="text-sm text-gray-600">Calories today</div>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{totalWeeklyEggs * 6}g</div>
                    <div className="text-sm text-gray-600">Weekly protein</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{Math.round(weeklyProgress)}%</div>
                    <div className="text-sm text-gray-600">Goal achievement</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recipe Generator */}
          <TabsContent value="generator" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card className="bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-orange-500" />
                    AI Recipe Generator
                  </CardTitle>
                  <CardDescription>Get personalized egg recipes based on your preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Dietary Preferences</Label>
                    <Select value={recipePreferences.dietary} onValueChange={(value) => 
                      setRecipePreferences({...recipePreferences, dietary: value})
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select dietary preference" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vegetarian">Vegetarian</SelectItem>
                        <SelectItem value="keto">Keto</SelectItem>
                        <SelectItem value="mediterranean">Mediterranean</SelectItem>
                        <SelectItem value="high-protein">High Protein</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Cooking Time</Label>
                    <Select value={recipePreferences.cookingTime} onValueChange={(value) => 
                      setRecipePreferences({...recipePreferences, cookingTime: value})
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select cooking time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="quick">Under 10 minutes</SelectItem>
                        <SelectItem value="medium">10-20 minutes</SelectItem>
                        <SelectItem value="long">20+ minutes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Difficulty Level</Label>
                    <Select value={recipePreferences.difficulty} onValueChange={(value) => 
                      setRecipePreferences({...recipePreferences, difficulty: value})
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Available Ingredients</Label>
                    <Textarea
                      placeholder="List ingredients you have available..."
                      value={recipePreferences.ingredients}
                      onChange={(e) => setRecipePreferences({...recipePreferences, ingredients: e.target.value})}
                    />
                  </div>

                  <Button 
                    onClick={generateRecipe}
                    className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white"
                  >
                    Generate Recipe
                  </Button>
                </CardContent>
              </Card>

              {generatedRecipe && (
                <Card className="bg-white shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {generatedRecipe.name}
                      <Badge className="bg-orange-100 text-orange-700">
                        {generatedRecipe.difficulty}
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      Cooking time: {generatedRecipe.time}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Ingredients:</h4>
                      <ul className="space-y-1">
                        {generatedRecipe.ingredients.map((ingredient: string, index: number) => (
                          <li key={index} className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                            <span className="text-sm">{ingredient}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Instructions:</h4>
                      <ol className="space-y-2">
                        {generatedRecipe.instructions.map((step: string, index: number) => (
                          <li key={index} className="flex gap-2">
                            <span className="flex-shrink-0 w-5 h-5 bg-orange-500 text-white rounded-full flex items-center justify-center text-xs font-bold">
                              {index + 1}
                            </span>
                            <span className="text-sm pt-0.5">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Supply Chain Tracker */}
          <TabsContent value="supply" className="space-y-6">
            <Card className="bg-white shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-orange-500" />
                  Egg Supply Chain Tracker
                </CardTitle>
                <CardDescription>Track the origin, quality, and safety of your eggs using blockchain technology</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Enter Batch ID or QR Code</Label>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="e.g., EGG-2024-001" 
                      defaultValue={trackingData.batchId}
                      className="flex-1"
                    />
                    <Button className="bg-orange-500 hover:bg-orange-600">Track</Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Origin Information</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <MapPin className="h-4 w-4 text-orange-500" />
                        <div>
                          <div className="font-medium">{trackingData.farm}</div>
                          <div className="text-sm text-gray-600">{trackingData.location}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Calendar className="h-4 w-4 text-orange-500" />
                        <div>
                          <div className="font-medium">Production Date</div>
                          <div className="text-sm text-gray-600">{trackingData.date}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <div>
                          <div className="font-medium">Quality Grade</div>
                          <div className="text-sm text-gray-600">{trackingData.quality}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Certifications</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <span className="font-medium">Organic Certified</span>
                        {trackingData.organic ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-red-500" />
                        )}
                      </div>

                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <span className="font-medium">Free Range</span>
                        {trackingData.freeRange ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-red-500" />
                        )}
                      </div>

                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <span className="font-medium">Delivery Status</span>
                        <Badge className="bg-blue-100 text-blue-700">
                          {trackingData.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="font-semibold text-lg mb-4">Supply Chain Journey</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">1</div>
                      <div>
                        <div className="font-medium">Farm Production</div>
                        <div className="text-sm text-gray-600">Eggs laid at {trackingData.farm}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">2</div>
                      <div>
                        <div className="font-medium">Quality Inspection</div>
                        <div className="text-sm text-gray-600">Graded as {trackingData.quality}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">3</div>
                      <div>
                        <div className="font-medium">Packaging & Distribution</div>
                        <div className="text-sm text-gray-600">Packaged and shipped to retailers</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">4</div>
                      <div>
                        <div className="font-medium">Retail Delivery</div>
                        <div className="text-sm text-gray-600">Available for purchase</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}