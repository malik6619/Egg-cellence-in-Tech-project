import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  Clock, 
  Users, 
  ChefHat, 
  Star,
  Heart,
  Bookmark
} from 'lucide-react';

export default function DishGallery() {
  const [searchTerm, setSearchTerm] = useState('');

  const dishes = [
    {
      id: 1,
      name: "Classic Scrambled Eggs",
      image: "🍳",
      category: "breakfast",
      difficulty: "Easy",
      time: "5 min",
      serves: "2",
      rating: 4.8,
      likes: 234,
      description: "Creamy, fluffy scrambled eggs cooked to perfection with butter and herbs.",
      ingredients: ["3 large eggs", "2 tbsp butter", "Salt & pepper", "Fresh chives"],
      instructions: [
        "Crack eggs into a bowl and whisk gently",
        "Heat butter in non-stick pan over low heat",
        "Add eggs and stir continuously with spatula",
        "Remove from heat while slightly underdone",
        "Season and garnish with chives"
      ]
    },
    {
      id: 2,
      name: "Eggs Benedict",
      image: "🥞",
      category: "brunch",
      difficulty: "Hard",
      time: "25 min",
      serves: "2",
      rating: 4.9,
      likes: 189,
      description: "Poached eggs on English muffins with Canadian bacon and hollandaise sauce.",
      ingredients: ["4 eggs", "2 English muffins", "4 slices Canadian bacon", "Hollandaise sauce"],
      instructions: [
        "Toast English muffin halves",
        "Warm Canadian bacon in pan",
        "Poach eggs in simmering water with vinegar",
        "Prepare hollandaise sauce",
        "Assemble and serve immediately"
      ]
    },
    {
      id: 3,
      name: "Vegetable Omelet",
      image: "🥗",
      category: "lunch",
      difficulty: "Medium",
      time: "12 min",
      serves: "1",
      rating: 4.7,
      likes: 156,
      description: "Fluffy omelet filled with fresh vegetables and herbs.",
      ingredients: ["3 eggs", "Bell peppers", "Onions", "Mushrooms", "Cheese", "Herbs"],
      instructions: [
        "Sauté vegetables until tender",
        "Beat eggs with salt and pepper",
        "Pour eggs into heated pan",
        "Add vegetables and cheese to one half",
        "Fold omelet and slide onto plate"
      ]
    },
    {
      id: 4,
      name: "Shakshuka",
      image: "🍅",
      category: "dinner",
      difficulty: "Medium",
      time: "20 min",
      serves: "4",
      rating: 4.6,
      likes: 298,
      description: "Eggs poached in spicy tomato sauce with peppers and onions.",
      ingredients: ["6 eggs", "Tomatoes", "Bell peppers", "Onions", "Spices", "Feta cheese"],
      instructions: [
        "Sauté onions and peppers",
        "Add tomatoes and spices, simmer",
        "Create wells in sauce for eggs",
        "Crack eggs into wells",
        "Cover and cook until eggs are set"
      ]
    },
    {
      id: 5,
      name: "Deviled Eggs",
      image: "🥚",
      category: "appetizer",
      difficulty: "Easy",
      time: "15 min",
      serves: "6",
      rating: 4.5,
      likes: 167,
      description: "Classic deviled eggs with creamy yolk filling and paprika garnish.",
      ingredients: ["6 hard-boiled eggs", "Mayonnaise", "Mustard", "Paprika", "Salt"],
      instructions: [
        "Hard boil eggs and cool completely",
        "Cut eggs in half and remove yolks",
        "Mix yolks with mayo, mustard, and seasonings",
        "Pipe or spoon mixture back into whites",
        "Garnish with paprika"
      ]
    },
    {
      id: 6,
      name: "Egg Fried Rice",
      image: "🍚",
      category: "dinner",
      difficulty: "Easy",
      time: "15 min",
      serves: "3",
      rating: 4.4,
      likes: 203,
      description: "Quick and delicious fried rice with scrambled eggs and vegetables.",
      ingredients: ["3 eggs", "3 cups cooked rice", "Mixed vegetables", "Soy sauce", "Green onions"],
      instructions: [
        "Scramble eggs and set aside",
        "Heat oil in wok or large pan",
        "Add rice and break up clumps",
        "Add vegetables and soy sauce",
        "Fold in scrambled eggs and green onions"
      ]
    }
  ];

  const categories = ["all", "breakfast", "brunch", "lunch", "dinner", "appetizer"];

  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDish, setSelectedDish] = useState<typeof dishes[0] | null>(null);

  const filteredDishes = dishes.filter(dish => {
    const matchesSearch = dish.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || dish.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-green-100 text-green-700";
      case "Medium": return "bg-yellow-100 text-yellow-700";
      case "Hard": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Egg Dish Gallery</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover delicious egg recipes from around the world with step-by-step instructions
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search recipes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white shadow-lg"
            />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category 
                  ? "bg-orange-500 hover:bg-orange-600" 
                  : "border-orange-200 text-orange-600 hover:bg-orange-50"
                }
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        {selectedDish ? (
          /* Recipe Detail View */
          <div className="max-w-4xl mx-auto">
            <Button 
              onClick={() => setSelectedDish(null)}
              variant="outline"
              className="mb-6"
            >
              ← Back to Gallery
            </Button>
            
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="text-6xl">{selectedDish.image}</div>
                  <div className="flex-1">
                    <CardTitle className="text-3xl text-gray-800 mb-2">{selectedDish.name}</CardTitle>
                    <CardDescription className="text-lg mb-4">{selectedDish.description}</CardDescription>
                    
                    <div className="flex flex-wrap gap-4 mb-4">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-orange-500" />
                        <span className="text-sm">{selectedDish.time}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-orange-500" />
                        <span className="text-sm">Serves {selectedDish.serves}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm">{selectedDish.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Heart className="h-4 w-4 text-red-500" />
                        <span className="text-sm">{selectedDish.likes}</span>
                      </div>
                    </div>
                    
                    <Badge className={getDifficultyColor(selectedDish.difficulty)}>
                      {selectedDish.difficulty}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <Tabs defaultValue="ingredients" className="space-y-6">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
                    <TabsTrigger value="instructions">Instructions</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="ingredients">
                    <div className="space-y-2">
                      <h3 className="text-lg font-semibold mb-4">Ingredients</h3>
                      <ul className="space-y-2">
                        {selectedDish.ingredients.map((ingredient, index) => (
                          <li key={index} className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                            <span>{ingredient}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="instructions">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold mb-4">Instructions</h3>
                      <ol className="space-y-3">
                        {selectedDish.instructions.map((step, index) => (
                          <li key={index} className="flex gap-3">
                            <span className="flex-shrink-0 w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                              {index + 1}
                            </span>
                            <span className="pt-0.5">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        ) : (
          /* Gallery Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDishes.map((dish) => (
              <Card key={dish.id} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-white cursor-pointer">
                <CardHeader className="text-center">
                  <div className="text-6xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {dish.image}
                  </div>
                  <CardTitle className="text-xl text-gray-800">{dish.name}</CardTitle>
                  <CardDescription className="text-gray-600">{dish.description}</CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="flex justify-between items-center mb-4">
                    <Badge className={getDifficultyColor(dish.difficulty)}>
                      {dish.difficulty}
                    </Badge>
                    <Badge variant="outline" className="border-orange-200 text-orange-600">
                      {dish.category}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {dish.time}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {dish.serves}
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      {dish.rating}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setSelectedDish(dish)}
                      className="flex-1 bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white"
                    >
                      <ChefHat className="mr-2 h-4 w-4" />
                      View Recipe
                    </Button>
                    <Button variant="outline" size="icon" className="border-orange-200 text-orange-600 hover:bg-orange-50">
                      <Bookmark className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {filteredDishes.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No recipes found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}