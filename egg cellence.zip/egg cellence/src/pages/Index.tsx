import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Egg, 
  BarChart3, 
  Camera, 
  Smartphone, 
  Users, 
  BookOpen,
  Zap,
  Heart,
  Shield,
  ArrowRight
} from 'lucide-react';

export default function Index() {
  const features = [
    {
      icon: <BarChart3 className="h-8 w-8 text-orange-600" />,
      title: "Nutrition Dashboard",
      description: "Interactive charts showing detailed nutritional information about eggs",
      link: "/nutrition",
      badge: "Data-Driven"
    },
    {
      icon: <Camera className="h-8 w-8 text-orange-600" />,
      title: "Dish Gallery",
      description: "Beautiful collection of egg recipes with cooking tips and user content",
      link: "/gallery",
      badge: "Visual"
    },
    {
      icon: <Smartphone className="h-8 w-8 text-orange-600" />,
      title: "IT Tools",
      description: "AI-powered recipe generator, egg tracker, and supply chain monitoring",
      link: "/tools",
      badge: "AI-Powered"
    },
    {
      icon: <Users className="h-8 w-8 text-orange-600" />,
      title: "Community",
      description: "Connect with fellow egg enthusiasts and share your experiences",
      link: "/community",
      badge: "Social"
    },
    {
      icon: <BookOpen className="h-8 w-8 text-orange-600" />,
      title: "Blog & News",
      description: "Latest articles on egg nutrition, recipes, and food technology",
      link: "/blog",
      badge: "Educational"
    }
  ];

  const stats = [
    { icon: <Zap className="h-6 w-6" />, value: "6g", label: "Protein per egg" },
    { icon: <Heart className="h-6 w-6" />, value: "13", label: "Essential vitamins" },
    { icon: <Shield className="h-6 w-6" />, value: "100%", label: "Natural goodness" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Egg className="h-20 w-20 text-orange-500 mx-auto mb-6 animate-bounce" />
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent mb-6">
              Egg-cellence in Tech
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-2xl mx-auto">
              Crack open the power of eggs and technology. Discover nutrition, recipes, and innovative solutions.
            </p>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 mb-12">
            {stats.map((stat, index) => (
              <div key={index} className="flex items-center space-x-2 bg-white rounded-full px-6 py-3 shadow-lg">
                <div className="text-orange-500">{stat.icon}</div>
                <div className="text-left">
                  <div className="font-bold text-lg text-gray-800">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-orange-500 hover:bg-orange-600 text-white">
              <Link to="/nutrition">
                Explore Nutrition <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-orange-500 text-orange-600 hover:bg-orange-50">
              <Link to="/tools">Try IT Tools</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Everything You Need for Egg Excellence
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              From nutrition tracking to recipe generation, we've got all your egg-related needs covered
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg bg-white">
                <CardHeader className="text-center pb-4">
                  <div className="mx-auto mb-4 p-3 bg-yellow-100 rounded-full w-fit group-hover:bg-orange-100 transition-colors">
                    {feature.icon}
                  </div>
                  <div className="flex justify-center mb-2">
                    <Badge variant="secondary" className="bg-yellow-200 text-orange-700">
                      {feature.badge}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl text-gray-800">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <CardDescription className="text-gray-600 mb-6">
                    {feature.description}
                  </CardDescription>
                  <Button asChild className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white">
                    <Link to={feature.link}>
                      Explore <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-yellow-400 to-orange-400">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Crack Into Something Amazing?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of egg enthusiasts who are already using our platform to track nutrition, discover recipes, and connect with the community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
              <Link to="/tools">Start Tracking</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-white text-white hover:bg-white/10">
              <Link to="/community">Join Community</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}